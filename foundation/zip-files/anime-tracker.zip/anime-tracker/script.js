import { CATEGORIES, createEntry, calculateStats, clampWatched, getTitle, isKnownTotal, progressPercent, readEntries, saveEntries } from './core.js';
import { refreshAnimeByIds, searchAnime } from './api.js';

// ----------------------------- App state -----------------------------------
const STORE_KEY = 'afterglow-anime-tracker-v1';
const entries = new Map();
function browserStorage() {
  try { return window.localStorage; } catch { return null; }
}
const storage = browserStorage();
const initialEntries = readEntries(storage, STORE_KEY);
for (const entry of initialEntries) entries.set(String(entry.id), entry);
let activeView = 'watching';
let searchResults = [];
let searchController = null;
let toastTimer = null;

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const collectionView = $('#collection-view');
const searchView = $('#search-view');
const statsView = $('#stats-view');
const collectionGrid = $('#collection-grid');
const collectionEmpty = $('#collection-empty');
const searchResultsEl = $('#search-results');
const searchMessage = $('#search-message');

// ----------------------------- Storage -------------------------------------
function persist() {
  const result = saveEntries(storage, STORE_KEY, [...entries.values()]);
  if (!result.ok) showToast('Could not save this change in browser storage. Check available storage space.');
}

// ----------------------------- AniList API ---------------------------------
async function refreshAllMetadata() {
  const list = [...entries.values()];
  if (!list.length) { showToast('Your list is empty — add an anime first.'); return; }
  const button = $('#refresh-metadata');
  button.disabled = true;
  button.innerHTML = '<span class="refresh-icon" aria-hidden="true">↻</span> Refreshing…';
  let updated = 0;
  try {
    for (let index = 0; index < list.length; index += 20) {
      const ids = list.slice(index, index + 20).map((item) => Number(item.id));
      const mediaList = await refreshAnimeByIds(ids);
      for (const media of mediaList) {
        const old = entries.get(String(media.id));
        if (old) {
          old.meta = media;
          old.watched = clampWatched(old.watched, media.episodes);
          updated += 1;
        }
      }
      if (index + 20 < list.length) await new Promise((resolve) => setTimeout(resolve, 550));
    }
    persist(); render(); showToast(`Updated details for ${updated} anime.`);
  } catch (error) {
    if (updated) { persist(); render(); }
    showToast(error.message || 'Could not refresh details. Your saved list is unchanged.');
  } finally {
    button.disabled = false;
    button.innerHTML = '<span class="refresh-icon" aria-hidden="true">↻</span> Refresh details';
  }
}

// ----------------------------- Display helpers -----------------------------
function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

function titleOf(entry) { return getTitle(entry.meta?.title, entry.id); }
function safeCover(meta) { return meta?.coverImage?.extraLarge || meta?.coverImage?.large || meta?.coverImage?.medium || ''; }
function formatStatus(value) {
  if (!value) return 'Status unknown';
  return String(value).toLowerCase().replaceAll('_', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
}
function releaseLabel(meta) {
  const season = meta?.season ? String(meta.season).toLowerCase().replace(/\b\w/g, (letter) => letter.toUpperCase()) : '';
  const year = Number.isFinite(meta?.seasonYear) ? String(meta.seasonYear) : '';
  if (season && year) return `${season} ${year}`;
  if (year) return year;
  return 'Release year unknown';
}
function formatHours(minutes) {
  const hours = minutes / 60;
  if (hours < 10) return hours.toFixed(1);
  return hours.toLocaleString(undefined, { maximumFractionDigits: 1 });
}
function categoryName(category) { return CATEGORIES[category] || category; }
function imageMarkup(meta, title) {
  const cover = safeCover(meta);
  if (!cover) return '<div class="cover-placeholder" aria-label="Cover unavailable">✦</div>';
  return `<img class="cover" src="${escapeHtml(cover)}" alt="Cover art for ${escapeHtml(title)}" loading="lazy" referrerpolicy="no-referrer"><div class="cover-shade"></div>`;
}
function badgeLabel(entry) { return categoryName(entry.category); }

function renderCard(entry) {
  const meta = entry.meta || {};
  const id = escapeHtml(entry.id);
  const title = titleOf(entry);
  const totalKnown = isKnownTotal(meta.episodes);
  const total = totalKnown ? Math.floor(meta.episodes) : null;
  const watched = clampWatched(entry.watched, total);
  const duration = Number.isFinite(meta.duration) && meta.duration > 0 ? `${meta.duration} min/episode` : '';
  const time = entry.category !== 'interested' && duration ? `<p class="card-time"><strong>${formatHours(watched * meta.duration)} hours watched</strong> <span>· est.</span></p>` : '';
  const statusChip = `<span class="meta-chip">${escapeHtml(formatStatus(meta.status))}</span>`;
  const yearChip = `<span class="meta-chip">${escapeHtml(releaseLabel(meta))}</span>`;
  let progress;
  let controls = '';
  if (entry.category === 'interested') {
    progress = `<div class="card-progress-line"><span class="episode-label">${totalKnown ? `${total} total episodes` : 'Episode count unknown'}</span></div>`;
    controls = `<div class="card-actions"><label class="sr-only" for="move-${id}">Move ${escapeHtml(title)} to another category</label><select id="move-${id}" class="move-select" data-action="move" data-id="${id}">${moveOptions(entry.category)}</select><button class="remove-button" data-action="remove" data-id="${id}" type="button">Remove</button></div>`;
  } else {
    const percentage = progressPercent(watched, total);
    const episodeText = `${watched} / ${totalKnown ? total : '?'} episodes`;
    progress = `<div class="card-progress-line"><span class="episode-label"><strong>${watched}</strong> / ${totalKnown ? total : '?'} episodes</span>${percentage !== null ? `<span class="percent-label">${percentage}%</span>` : ''}</div>${percentage !== null ? `<div class="progress-track" role="progressbar" aria-label="${escapeHtml(title)} episode progress" aria-valuemin="0" aria-valuemax="${total}" aria-valuenow="${watched}"><div class="progress-fill" style="width:${percentage}%"></div></div>` : '<div class="unknown-track" aria-label="Progress unavailable because total episode count is unknown"></div>'}`;
    const maxAttribute = totalKnown ? `max="${total}"` : '';
    controls = `<div class="episode-controls"><button class="step-button" type="button" data-action="decrease" data-id="${id}" aria-label="Decrease watched episodes for ${escapeHtml(title)}" ${watched <= 0 ? 'disabled' : ''}>−</button><label class="sr-only" for="watched-${id}">Watched episode count for ${escapeHtml(title)}</label><input id="watched-${id}" class="watched-input" type="number" inputmode="numeric" min="0" ${maxAttribute} step="1" value="${watched}" data-action="edit-count" data-id="${id}"><span class="control-total">of ${totalKnown ? total : '?'}</span><button class="step-button" type="button" data-action="increase" data-id="${id}" aria-label="Increase watched episodes for ${escapeHtml(title)}" ${(totalKnown && watched >= total) ? 'disabled' : ''}>+</button><span class="control-spacer"></span></div><div class="card-actions"><label class="sr-only" for="move-${id}">Move ${escapeHtml(title)} to another category</label><select id="move-${id}" class="move-select" data-action="move" data-id="${id}">${moveOptions(entry.category)}</select><button class="remove-button" data-action="remove" data-id="${id}" type="button">Remove</button></div>`;
  }
  return `<article class="anime-card ${entry.category === 'interested' ? 'interested-card' : ''}" data-id="${id}"><div class="cover-wrap">${imageMarkup(meta, title)}<span class="cover-badge"><i></i>${escapeHtml(badgeLabel(entry))}</span></div><div class="card-body"><h3 class="card-title" title="${escapeHtml(title)}">${escapeHtml(title)}</h3><p class="card-subtitle">${escapeHtml(meta.title?.romaji && meta.title?.english ? meta.title.romaji : (meta.format ? String(meta.format).replaceAll('_', ' ') : releaseLabel(meta)))}</p>${progress}<div class="card-meta">${duration ? `<span class="meta-chip">${escapeHtml(duration)}</span>` : ''}${statusChip}${entry.category === 'interested' ? yearChip : ''}</div>${time}${controls}</div></article>`;
}

function moveOptions(current) {
  return Object.entries(CATEGORIES).filter(([key]) => key !== current).map(([key, label]) => `<option value="${key}">Move to ${label}</option>`).join('');
}

function renderCollection() {
  const categoryEntries = [...entries.values()].filter((entry) => entry.category === activeView);
  const filter = $('#list-search').value.trim().toLocaleLowerCase();
  const sort = $('#sort-order').value;
  const visible = categoryEntries.filter((entry) => `${titleOf(entry)} ${entry.meta?.title?.romaji || ''} ${entry.meta?.title?.english || ''}`.toLocaleLowerCase().includes(filter));
  visible.sort((a, b) => {
    if (sort === 'alphabetical') return titleOf(a).localeCompare(titleOf(b));
    if (sort === 'watched') return (b.watched || 0) - (a.watched || 0);
    if (sort === 'total') return (Number(b.meta?.episodes) || 0) - (Number(a.meta?.episodes) || 0);
    return (b.addedAt || 0) - (a.addedAt || 0);
  });
  collectionGrid.innerHTML = visible.map(renderCard).join('');
  const heading = { watching: 'Currently watching', completed: 'Completed anime', interested: 'On your list' }[activeView];
  $('#collection-heading').textContent = heading;
  collectionEmpty.hidden = categoryEntries.length > 0;
  if (categoryEntries.length === 0) collectionGrid.hidden = true;
  else collectionGrid.hidden = false;
  if (categoryEntries.length > 0 && visible.length === 0) collectionGrid.innerHTML = '<div class="empty-filter">No anime match that filter.</div>';
}

function renderCounts() {
  for (const category of Object.keys(CATEGORIES)) $(`#nav-${category}`).textContent = String([...entries.values()].filter((entry) => entry.category === category).length);
  $('#quick-total').textContent = String(entries.size);
  const stats = calculateStats([...entries.values()]);
  $('#quick-episodes').textContent = stats.episodes.toLocaleString();
}

function renderStats() {
  const stats = calculateStats([...entries.values()]);
  $('#stat-total').textContent = String(entries.size);
  $('#stat-watching').textContent = String(stats.counts.watching);
  $('#stat-completed').textContent = String(stats.counts.completed);
  $('#stat-interested').textContent = String(stats.counts.interested);
  $('#stat-episodes').textContent = stats.episodes.toLocaleString();
  $('#stat-hours').textContent = formatHours(stats.minutes);
  $('#stat-days').textContent = (stats.minutes / 1440).toLocaleString(undefined, { maximumFractionDigits: 1 });
  const max = Math.max(stats.categoryEpisodes.watching, stats.categoryEpisodes.completed, 1);
  for (const category of ['watching', 'completed']) {
    const value = stats.categoryEpisodes[category];
    $(`#bar-${category}`).style.width = `${Math.round(value / max * 100)}%`;
    $(`#bar-${category}-value`).textContent = value.toLocaleString();
  }
}

function render() {
  renderCounts();
  renderStats();
  if (activeView === 'stats' || activeView === 'search') return;
  renderCollection();
}

function renderResults() {
  const category = $('#add-category').value;
  searchResultsEl.innerHTML = searchResults.map((media) => {
    const id = String(media.id);
    const title = getTitle(media.title, id);
    const existing = entries.get(id);
    const total = isKnownTotal(media.episodes) ? `${Math.floor(media.episodes)} episodes` : 'Episode count unknown';
    const format = media.format ? String(media.format).replaceAll('_', ' ') : 'Format unknown';
    const description = media.description ? media.description.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim() : 'No description provided by AniList.';
    const addButton = existing
      ? `<p class="duplicate-note">Already in ${escapeHtml(categoryName(existing.category))}</p>`
      : `<button class="button button-primary result-add" type="button" data-action="add-result" data-id="${escapeHtml(id)}">＋ Add to ${escapeHtml(categoryName(category))}</button>`;
    return `<article class="anime-card result-card" data-id="${escapeHtml(id)}"><div class="cover-wrap">${imageMarkup(media, title)}<span class="cover-badge"><i></i>${escapeHtml(formatStatus(media.status))}</span></div><div class="card-body"><h3 class="card-title" title="${escapeHtml(title)}">${escapeHtml(title)}</h3><p class="card-subtitle">${escapeHtml(media.title?.romaji && media.title?.english ? media.title.romaji : format)}</p><div class="result-info"><span><strong>${escapeHtml(String(media.seasonYear || 'Year unknown'))}</strong> · ${escapeHtml(format)}</span><span><strong>${escapeHtml(total)}</strong></span><span>AniList ID: ${escapeHtml(id)}</span></div><p class="result-desc">${escapeHtml(description)}</p>${addButton}</div></article>`;
  }).join('');
  if (searchResults.length === 0) searchResultsEl.innerHTML = '';
}

// ----------------------------- Navigation ----------------------------------
function setView(view) {
  activeView = view;
  collectionView.hidden = view === 'search' || view === 'stats';
  searchView.hidden = view !== 'search';
  statsView.hidden = view !== 'stats';
  $$('.nav-link').forEach((button) => button.classList.toggle('is-active', button.dataset.view === view));
  if (view !== 'search' && view !== 'stats') renderCollection();
  if (view === 'stats') renderStats();
  window.location.hash = view === 'search' ? 'add' : view;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('is-visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 3200);
}

function setSearchMessage(message, type = '') {
  searchMessage.textContent = message;
  searchMessage.className = `message ${type}`.trim();
}

// ----------------------------- Mutations -----------------------------------
function addMedia(media, category) {
  const id = String(media.id);
  const existing = entries.get(id);
  if (existing) {
    showToast(`Already in ${categoryName(existing.category)} — duplicates are not added.`);
    renderResults();
    return false;
  }
  entries.set(id, createEntry(media, category));
  persist(); render();
  showToast(`${getTitle(media.title, id)} added to ${categoryName(category)}.`);
  return true;
}

function setWatched(id, rawValue) {
  const entry = entries.get(String(id));
  if (!entry || entry.category === 'interested') return;
  const number = Number(rawValue);
  const value = clampWatched(Number.isFinite(number) ? Math.floor(number) : 0, entry.meta?.episodes);
  entry.watched = value;
  persist(); render();
}

function moveEntry(id, category) {
  const entry = entries.get(String(id));
  if (!entry || !CATEGORIES[category] || entry.category === category) return;
  entry.category = category;
  entry.watched = clampWatched(entry.watched, entry.meta?.episodes);
  persist(); render();
  showToast(`Moved to ${categoryName(category)}.`);
}

// ----------------------------- Event handling ------------------------------
$$('.nav-link').forEach((button) => button.addEventListener('click', () => setView(button.dataset.view)));
['open-search', 'hero-add', 'empty-add'].forEach((id) => $(`#${id}`).addEventListener('click', () => setView('search')));
$('#list-search').addEventListener('input', renderCollection);
$('#sort-order').addEventListener('change', renderCollection);
$('#refresh-metadata').addEventListener('click', refreshAllMetadata);
$('#add-category').addEventListener('change', renderResults);

$('#search-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const term = $('#anime-query').value.trim();
  if (term.length < 2) { setSearchMessage('Enter at least two characters to search.', 'error'); return; }
  if (searchController) searchController.abort();
  searchController = new AbortController();
  const button = $('.search-submit');
  button.disabled = true;
  searchResults = [];
  renderResults();
  setSearchMessage('Searching AniList…');
  try {
    const found = await searchAnime(term, searchController.signal);
    const unique = new Map(found.filter((media) => media?.id != null).map((media) => [String(media.id), media]));
    searchResults = [...unique.values()];
    renderResults();
    setSearchMessage(searchResults.length ? `${searchResults.length} results for “${term}”.` : `No anime found for “${term}”. Try another title.`, searchResults.length ? '' : '');
  } catch (error) {
    if (error.name !== 'AbortError') setSearchMessage(error.message || 'Search failed. Your saved list is still available.', 'error');
  } finally {
    button.disabled = false;
  }
});

searchResultsEl.addEventListener('click', (event) => {
  const button = event.target.closest('[data-action="add-result"]');
  if (!button) return;
  const media = searchResults.find((item) => String(item.id) === button.dataset.id);
  if (media) addMedia(media, $('#add-category').value);
  renderResults();
});

collectionGrid.addEventListener('click', (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const entry = entries.get(String(button.dataset.id));
  if (!entry) return;
  const total = entry.meta?.episodes;
  if (button.dataset.action === 'increase') setWatched(entry.id, (entry.watched || 0) + 1);
  if (button.dataset.action === 'decrease') setWatched(entry.id, (entry.watched || 0) - 1);
  if (button.dataset.action === 'remove') {
    entries.delete(String(entry.id)); persist(); render(); showToast(`${titleOf(entry)} removed from your list.`);
  }
});

collectionGrid.addEventListener('change', (event) => {
  const target = event.target;
  if (target.dataset.action === 'move') moveEntry(target.dataset.id, target.value);
  if (target.dataset.action === 'edit-count') setWatched(target.dataset.id, target.value);
});

collectionGrid.addEventListener('keydown', (event) => {
  if (event.target.matches('[data-action="edit-count"]') && event.key === 'Enter') {
    event.preventDefault(); event.target.blur();
  }
});

window.addEventListener('hashchange', () => {
  const hash = window.location.hash.replace('#', '');
  if (hash === 'add') setView('search');
  else if (hash === 'stats') setView('stats');
  else if (CATEGORIES[hash]) setView(hash);
});

// ----------------------------- Initial render ------------------------------
const initialHash = window.location.hash.replace('#', '');
if (initialHash === 'add') activeView = 'search';
else if (initialHash === 'stats') activeView = 'stats';
else if (CATEGORIES[initialHash]) activeView = initialHash;
setView(activeView);
render();
