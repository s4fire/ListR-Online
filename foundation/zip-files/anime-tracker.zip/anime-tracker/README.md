# Afterglow — Anime Tracker

A personal anime tracker built with **HTML5, CSS3, and vanilla JavaScript**. It searches AniList’s public GraphQL API and stores your list in the current browser with `localStorage`—no account, backend, build step, or paid service is required.

## Features

- **Watching, Completed, and Interested** lists keyed by AniList media ID.
- AniList search results with cover, year, format, status, episode count, and description.
- Episode increment/decrement and direct editing, with values clamped to zero and a known total.
- Completed anime are set to their known episode total when first added; the count remains editable.
- Unknown episode totals show `watched / ? episodes` and have no fabricated percentage.
- Interested anime do not contribute to watched-episode or time statistics.
- Move anime between categories, avoid duplicates, filter and sort your collection, and remove entries.
- Watch-time estimates use AniList duration only; entries without a known duration are excluded from time totals.
- Metadata refresh, responsive layout, and useful API/network/rate-limit errors.

## Project files

```text
index.html       App shell and accessible page structure
style.css        Responsive dark anime-inspired interface
script.js        View rendering, tracker controls, and UI events
api.js           AniList GraphQL search and metadata-refresh client
core.js          Tracker rules, statistics, and localStorage helpers
tests/core.test.mjs  Dependency-free tracker and API-client tests
```

## Run locally

Because the app uses JavaScript modules, open it from a local static HTTP server rather than `file://`:

```bash
python3 -m http.server 8000
```

Then visit <http://localhost:8000>. Python is only used here as a convenient local static-file server; the website itself has **no Python or server-side dependency**. Alternatively, use any static-file server. The browser must be online for AniList search and metadata refresh; your previously saved list remains available offline.

Run the included logic tests with Node.js 18 or later:

```bash
node --test tests/core.test.mjs
```

## Publish with GitHub Pages

1. Create a new repository on GitHub, for example `anime-tracker`.
2. Upload or push **the contents of this folder** to the repository root. Keep `index.html`, `style.css`, `script.js`, `api.js`, and `core.js` together at that root; keep the `tests/` folder if you want the tests.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your publishing branch (commonly `main`) and the `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish. A project site will typically be at `https://USERNAME.github.io/anime-tracker/`.

All app asset/module references are relative (`./style.css`, `./script.js`, `./api.js`, and `./core.js`), so the site works at a repository subpath as well as at a domain root. No build command or GitHub Actions workflow is needed for the branch-based Pages option.

## Data and limitations

- Your tracker is stored in browser-local storage on this device/browser. It does not sync to other devices and clearing site data will remove it. Use your browser’s storage backup options if you need to preserve it elsewhere.
- The AniList API is an external service and may be unavailable or rate-limited. API errors do not erase the saved collection.
- Covers and live metadata are provided by AniList. Missing data remains missing rather than being guessed.
- AniList episode counts represent the **series total**; your watched count is stored separately.
